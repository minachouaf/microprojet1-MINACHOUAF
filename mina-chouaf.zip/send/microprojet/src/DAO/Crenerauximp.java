
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import pack.Crenereux;

public class Crenerauximp implements INcreneraux {
	Connection cnx=null;
	PreparedStatement prepared=null;
	ResultSet resultat=null;
	public Crenerauximp() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addcreneraux(Crenereux A) {
		cnx =ConnexionMysql.ConnecrDb();
		String sql="insert into creneraux(VERSION,HDEBUT,MDEBUT,HFIN,MFIN,ID_MEDECIN ) values(?,?,?,?,?,?)";
		try {
		prepared=cnx.prepareStatement(sql);
		
		prepared.setString(1,A.getversion());
		prepared.setString(2,A.gethdebut());
		prepared.setString(3,A.getmdebut());
		prepared.setString(4,A.gethfin());
		prepared.setString(5,A.getmfin());
		prepared.setString(6,A.getidmedecin());
		
	

		prepared.execute();

			JOptionPane.showMessageDialog(null,"ajout avec succes");
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	}

	@Override
	public void updatecreneraux(Crenereux A) {
		String t1=A.getid();
		String t2=A.getversion();
		String t3=A.gethdebut();
		String t4=A.getmdebut();
		String t5=A.gethfin();
		String t6=A.getmfin();
		String t7=A.getidmedecin();
		cnx =ConnexionMysql.ConnecrDb();

		String sql="update creneraux set  version='"+t2+"',HDEBUT='"+t3+"',MDEBUT='"+t4+"',HFIN='"+t5+"',MFIN='"+t6+"',ID_MEDECIN='"+t7+"' where ID='"+t1+"'";
		try {
			prepared=cnx.prepareStatement(sql);
			prepared.execute();

			JOptionPane.showMessageDialog(null,"update avec succes");
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	}

	
	public void deletecreneraux(String a) {
		cnx =ConnexionMysql.ConnecrDb();
		try {

			String sql="delete from creneraux where ID= ?";
			prepared= cnx.prepareStatement(sql);
			prepared.setString(1,a);
		
				prepared.execute();

				JOptionPane.showMessageDialog(null,"suppression avec succes");
				
			

			}catch(Exception ee) {
				ee.printStackTrace();
			}
	}

	@Override
	public Crenereux getcrenerau(String id) {
		cnx =ConnexionMysql.ConnecrDb();
		String sql="select * from creneraux where ID=?";
		Crenereux m=null;
		try {
			
			prepared=cnx.prepareStatement(sql);
			prepared.setString(1,id);
			resultat=prepared.executeQuery();
			while(resultat.next())
			{
				 m=new Crenereux(resultat.getString(1),resultat.getString(2),resultat.getString(3),resultat.getString(4),resultat.getString(5),resultat.getString(6),resultat.getString(7));
			
			}
			

		}catch(Exception e4) {
		
			System.out.println(e4);
			

	}
		return m;
		
	}

	@Override
	public List<Crenereux> getcreneraux() {
		cnx =ConnexionMysql.ConnecrDb();
		 List <Crenereux>lm=new ArrayList<>();
		try {
			String sql ="Select * from clients";
			
			prepared=cnx.prepareStatement(sql);
			resultat=prepared.executeQuery(sql);
			while(resultat.next())
			{
				Crenereux m=new Crenereux(resultat.getString(1),resultat.getString(2),resultat.getString(3),resultat.getString(4),resultat.getString(5),resultat.getString(6),resultat.getString(7));
				lm.add(m);
			}
			
				}catch(Exception e) {
					System.out.println(e);
				
				}
		return lm;
		}

	
	


	
		
	

}

