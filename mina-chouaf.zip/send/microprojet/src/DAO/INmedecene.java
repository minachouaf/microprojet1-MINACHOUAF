package DAO;
import pack.Medecine;
import java.*;
import java.util.List;

public interface INmedecene {
	public void addmedecine(Medecine A);
	public void updatemedecine(Medecine A);
	public Medecine getmedecine(String id);
public List<Medecine> getmedecines();
}
