package DAO;
import pack.RV;
import java.*;
import java.util.List;

public interface INrv {
	public void addrv(RV A);
	public void updaterv(RV A);
public void deleterv(String a);
	public RV getRV(String id);
public List<RV> getRVS();
}

