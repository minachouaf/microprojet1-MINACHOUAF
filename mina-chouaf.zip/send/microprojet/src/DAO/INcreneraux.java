package DAO;
import pack.Crenereux;
import java.*;
import java.util.List;

public interface INcreneraux {
	public void addcreneraux(Crenereux A);
	public void updatecreneraux(Crenereux A);
public void deletecreneraux(String a);
	public Crenereux getcrenerau(String id);
public List<Crenereux> getcreneraux();
}

