package DAO;
import pack.Client;
import java.*;
import java.util.List;

public interface INclient {
	public void addclient(Client A);
	public void updateclient(Client A);
public void deleteclient(String a);
	public Client getclient(String id);
public List<Client> getclients();
}

