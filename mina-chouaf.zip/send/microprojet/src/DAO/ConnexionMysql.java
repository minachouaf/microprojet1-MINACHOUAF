package DAO;

import javax.swing.*;
import java.sql.*;

public class ConnexionMysql {

	
	Connection conn=null;
	public static Connection ConnecrDb() {

	try {
		Class.forName("com.mysql.jdbc.Driver");
	Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/microprojet","root","");
	System.out.println(" connection");
	
	return conn;

					}catch(Exception e){

						System.out.println("errroe de connection");
	return null;
	}}} 
					
