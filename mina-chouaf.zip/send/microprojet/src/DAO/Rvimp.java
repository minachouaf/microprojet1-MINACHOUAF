
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import pack.RV;

public class Rvimp implements INrv {
	Connection cnx=null;
	PreparedStatement prepared=null;
	ResultSet resultat=null;
	public Rvimp() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addrv(RV A) {
		cnx =ConnexionMysql.ConnecrDb();
		String sql="insert into rv(JOUR,ID_CLIENT,ID_CRENEAU) values(?,?,?)";
		try {
		prepared=cnx.prepareStatement(sql);
		
		prepared.setString(1,A.getjour());
		prepared.setString(2,A.getidclient());
		prepared.setString(3,A.getidcrenerau());
		
		
	

		prepared.execute();

			JOptionPane.showMessageDialog(null,"ajout avec succes");
		}catch(Exception e1) {
			System.out.println("fatal");
			JOptionPane.showMessageDialog(null,"fatal");
		}
	}

	@Override
	public void updaterv(RV A) {
		String t1=A.getid();
		String t2=A.getjour();
		String t3=A.getidclient();
		String t4=A.getidcrenerau();
	
		cnx =ConnexionMysql.ConnecrDb();

		String sql="update rv set  JOUR='"+t2+"',ID_CLIENT='"+t3+"',ID_CRENEAU='"+t4+"' where ID='"+t1+"'";
		try {
			prepared=cnx.prepareStatement(sql);
			prepared.execute();

			JOptionPane.showMessageDialog(null,"update avec succes");
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	}

	
	public void deleterv(String a) {
		cnx =ConnexionMysql.ConnecrDb();
		try {

			String sql="delete from rv where ID= ?";
			prepared= cnx.prepareStatement(sql);
			prepared.setString(1,a);
		
				prepared.execute();

				JOptionPane.showMessageDialog(null,"suppression avec succes");
				
			

			}catch(Exception ee) {
				ee.printStackTrace();
			}
	}

	@Override
	public RV getRV(String id) {
		cnx =ConnexionMysql.ConnecrDb();
		String sql="select * from rv where ID=?";
		RV m=null;
		try {
			
			prepared=cnx.prepareStatement(sql);
			prepared.setString(1,id);
			resultat=prepared.executeQuery();
			while(resultat.next())
			{
				 m=new RV(resultat.getString(1),resultat.getString(2),resultat.getString(3),resultat.getString(4));
			
			}
			

		}catch(Exception e4) {
		
			System.out.println(e4);
			

	}
		return m;
		
	}

	@Override
	public List<RV> getRVS() {
		cnx =ConnexionMysql.ConnecrDb();
		 List <RV>lm=new ArrayList<>();
		try {
			String sql ="Select * from rv";
			
			prepared=cnx.prepareStatement(sql);
			resultat=prepared.executeQuery(sql);
			while(resultat.next())
			{
				RV m=new RV(resultat.getString(1),resultat.getString(2),resultat.getString(3),resultat.getString(4));
				lm.add(m);
			}
			
				}catch(Exception e) {
					System.out.println(e);
				
				}
		return lm;
		}

	
	


	
		
	

}

