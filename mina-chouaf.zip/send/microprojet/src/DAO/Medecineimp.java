package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import pack.Medecine;

public class Medecineimp implements INmedecene {
	Connection cnx=null;
	PreparedStatement prepared=null;
	ResultSet resultat=null;
	public Medecineimp() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addmedecine(Medecine A) {
		cnx =ConnexionMysql.ConnecrDb();
		String sql="insert into medecins(ID,version,TITRE,NOM,PRENOM ) values(?,?,?,?,?)";
		try {
		prepared=cnx.prepareStatement(sql);
		prepared.setString(1,A.getid());
		prepared.setString(2,A.getversion());
		prepared.setString(3,A.gettitre());
		prepared.setString(4,A.getnom());
		prepared.setString(5,A.getprenom());
		
	

		prepared.execute();

			JOptionPane.showMessageDialog(null,"ajout avec succes");
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	}

	@Override
	public void updatemedecine(Medecine A) {
		String t2=A.getid();
		String t3=A.getversion();
		String t4=A.gettitre();
		String t5=A.getnom();
		String t6=A.getprenom();
		cnx =ConnexionMysql.ConnecrDb();

		String sql="update medecins set  version='"+t3+"',TITRE='"+t4+"',NOM='"+t5+"',PRENOM='"+t6+"' where ID='"+t2+"'";
		try {
			prepared=cnx.prepareStatement(sql);
			prepared.execute();

			JOptionPane.showMessageDialog(null,"update avec succes");
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	}

	
	public void deletemedecine(String a) {
		cnx =ConnexionMysql.ConnecrDb();
		try {

			String sql="delete from  medecins where ID= ?";
			prepared= cnx.prepareStatement(sql);
			prepared.setString(1,a);
		
				prepared.execute();

				JOptionPane.showMessageDialog(null,"suppression avec succes");
				
			

			}catch(Exception ee) {
				ee.printStackTrace();
			}
	}

	@Override
	public Medecine getmedecine(String id) {
		cnx =ConnexionMysql.ConnecrDb();
		String sql="select * from medecins where ID=?";
		Medecine m=null;
		try {
			
			prepared=cnx.prepareStatement(sql);
			prepared.setString(1,id);
			resultat=prepared.executeQuery();
			while(resultat.next())
			{
				 m=new Medecine(resultat.getString(1),resultat.getString(2),resultat.getString(3),resultat.getString(4),resultat.getString(5));
			
			}
			

		}catch(Exception e4) {
		
			System.out.println(e4);
			

	}
		return m;
		
	}

	@Override
	public List<Medecine> getmedecines() {
		cnx =ConnexionMysql.ConnecrDb();
		 List <Medecine>lm=new ArrayList<>();
		try {
			String sql ="Select * from medecins";
			
			prepared=cnx.prepareStatement(sql);
			resultat=prepared.executeQuery(sql);
			while(resultat.next())
			{
				Medecine m=new Medecine(resultat.getString(1),resultat.getString(2),resultat.getString(3),resultat.getString(4),resultat.getString(5));
				lm.add(m);
			}
			
				}catch(Exception e) {
					System.out.println(e);
				
				}
		return lm;
		}
	
		
	

}
