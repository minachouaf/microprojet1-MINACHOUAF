
package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

import pack.Client;

public class Clientimp implements INclient {
	Connection cnx=null;
	PreparedStatement prepared=null;
	ResultSet resultat=null;
	public Clientimp() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void addclient(Client A) {
		cnx =ConnexionMysql.ConnecrDb();
		String sql="insert into clients(ID,version,TITRE,NOM,PRENOM ) values(?,?,?,?,?)";
		try {
		prepared=cnx.prepareStatement(sql);
		prepared.setString(1,A.getid());
		prepared.setString(2,A.getversion());
		prepared.setString(3,A.gettitre());
		prepared.setString(4,A.getnom());
		prepared.setString(5,A.getprenom());
		
	

		prepared.execute();

			JOptionPane.showMessageDialog(null,"ajout avec succes");
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	}

	@Override
	public void updateclient(Client A) {
		String t2=A.getid();
		String t3=A.getversion();
		String t4=A.gettitre();
		String t5=A.getnom();
		String t6=A.getprenom();
		cnx =ConnexionMysql.ConnecrDb();

		String sql="update clients set  version='"+t3+"',TITRE='"+t4+"',NOM='"+t5+"',PRENOM='"+t6+"' where ID='"+t2+"'";
		try {
			prepared=cnx.prepareStatement(sql);
			prepared.execute();

			JOptionPane.showMessageDialog(null,"update avec succes");
		}catch(Exception e1) {
			e1.printStackTrace();
		}
	}

	
	public void deleteclient(String a) {
		cnx =ConnexionMysql.ConnecrDb();
		try {

			String sql="delete from client where ID= ?";
			prepared= cnx.prepareStatement(sql);
			prepared.setString(1,a);
		
				prepared.execute();

				JOptionPane.showMessageDialog(null,"suppression avec succes");
				
			

			}catch(Exception ee) {
				ee.printStackTrace();
			}
	}

	@Override
	public Client getclient(String id) {
		cnx =ConnexionMysql.ConnecrDb();
		String sql="select * from clienst where ID=?";
		Client m=null;
		try {
			
			prepared=cnx.prepareStatement(sql);
			prepared.setString(1,id);
			resultat=prepared.executeQuery();
			while(resultat.next())
			{
				 m=new Client(resultat.getString(1),resultat.getString(2),resultat.getString(3),resultat.getString(4),resultat.getString(5));
			
			}
			

		}catch(Exception e4) {
		
			System.out.println(e4);
			

	}
		return m;
		
	}

	@Override
	public List<Client> getclients() {
		cnx =ConnexionMysql.ConnecrDb();
		 List <Client>lm=new ArrayList<>();
		try {
			String sql ="Select * from clients";
			
			prepared=cnx.prepareStatement(sql);
			resultat=prepared.executeQuery(sql);
			while(resultat.next())
			{
				Client m=new Client(resultat.getString(1),resultat.getString(2),resultat.getString(3),resultat.getString(4),resultat.getString(5));
				lm.add(m);
			}
			
				}catch(Exception e) {
					System.out.println(e);
				
				}
		return lm;
		}


	
		
	

}

