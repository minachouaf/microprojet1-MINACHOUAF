package pack;

public class Client {
private String id;
private String version;
private String titre;
private String nom;
private String prenom;
	public Client(String id,String version,String titre,String nom,String prenom) {
		this.id=id;
		this.version=version;
		this.titre=titre;
		this.nom=nom;
		this.prenom=prenom;
	}
	public Client() {
		this.id="";
		this.version="";
		this.titre="";
		this.nom="";
		this.prenom="";
	}

	public String getid()
	{
		return this.id;
	}
	public String getversion()
	{
		return this.version;
	}
	public String gettitre()
	{
		return this.titre;
	}
	public String getnom()
	{
		return this.nom;
	}
	public String getprenom()
	{
		return this.prenom;
	}
}
