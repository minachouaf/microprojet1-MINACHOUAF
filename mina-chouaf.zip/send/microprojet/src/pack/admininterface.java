package pack;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Window.Type;
import java.awt.Color;
import javax.swing.UIManager;
import java.awt.SystemColor;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.FlowLayout;

public class admininterface extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		 try {
	            //here you can put the selected theme class name in JTattoo
	            UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
	        } catch (Exception ex) {
	        	System.out.print(ex);
	        }
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					admininterface frame = new admininterface();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public admininterface() {
		setType(Type.UTILITY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 897, 614);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 909, 58);
		panel.setBackground(new Color(153, 0, 0));
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.exit(0);
			}
		});
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\Amina\\Downloads\\iconfinder_icon-close_211652.png"));
		lblNewLabel.setBounds(853, 11, 30, 30);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_5 = new JLabel("Espace Administrateur");
		lblNewLabel_5.setFont(new Font("Arial", Font.BOLD, 16));
		lblNewLabel_5.setForeground(Color.WHITE);
		lblNewLabel_5.setBounds(242, 19, 227, 22);
		panel.add(lblNewLabel_5);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 0, 225, 585);
		panel_1.setBackground(new Color(0, 0, 0));
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		
		
		
	
		
		
		
		
		JButton btnNewButton_5 = new JButton("D\u00E9connexion");
		btnNewButton_5.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				new login().show();
			}
		});
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_5.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton_5.setBackground(Color.BLACK);
		btnNewButton_5.setForeground(Color.WHITE);
		btnNewButton_5.setBounds(29, 252, 186, 53);
		panel_1.add(btnNewButton_5);
		
		JButton btnAdministration = new JButton("Home");
		btnAdministration.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				//new home1().show();
			}
		});
		btnAdministration.setBounds(29, 132, 186, 53);
		panel_1.add(btnAdministration);
		btnAdministration.setBackground(Color.BLACK);
		btnAdministration.setForeground(Color.WHITE);
		btnAdministration.setFont(new Font("Tahoma", Font.BOLD, 11));
		
		JPanel panel_2 = new JPanel();
		panel_2.setBounds(224, 51, 671, 534);
		contentPane.add(panel_2);
		panel_2.setLayout(null);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(0, 0, 671, 523);
		panel_2.add(panel_3);
		panel_3.setLayout(null);
		
		JButton btnNewButton_7 = new JButton("GESTION DES CLIENTS");
		btnNewButton_7.setForeground(Color.WHITE);
		btnNewButton_7.setBounds(79, 377, 203, 107);
		panel_3.add(btnNewButton_7);
		btnNewButton_7.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
				new Clientmain().show();
			}
		});
		btnNewButton_7.setBackground(UIManager.getColor("TextField.selectionBackground"));
		btnNewButton_7.setFont(new Font("Tahoma", Font.BOLD, 11));
		
		JButton btnGestionDesFournisseurs = new JButton("GESTION DES RENDEZ-VOUS");
		btnGestionDesFournisseurs.setForeground(Color.WHITE);
		btnGestionDesFournisseurs.setBounds(352, 132, 203, 107);
		panel_3.add(btnGestionDesFournisseurs);
		btnGestionDesFournisseurs.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				new RVmain().show();
			}
		});
		btnGestionDesFournisseurs.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnGestionDesFournisseurs.setBackground(UIManager.getColor("TextField.selectionBackground"));
		
		JButton btnNewButton_8 = new JButton("GESTION DES CRENAUX");
		btnNewButton_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_8.setForeground(Color.WHITE);
		btnNewButton_8.setBounds(370, 376, 184, 107);
		panel_3.add(btnNewButton_8);
		btnNewButton_8.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
					new Crenerauxmain().show();
			}
		});
		btnNewButton_8.setBackground(UIManager.getColor("TextField.selectionBackground"));
		btnNewButton_8.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		JButton btnNewButton = new JButton("GESTION DES MEDECINES");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBounds(60, 132, 203, 107);
		panel_3.add(btnNewButton);
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				new Medecinemain().show();
			}
		});
		btnNewButton.setBackground(UIManager.getColor("TextPane.selectionBackground"));
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Amina\\Desktop\\B\\DATA-.gif"));
		lblNewLabel_1.setBounds(-10, -13, 671, 552);
		panel_3.add(lblNewLabel_1);
	}
}
