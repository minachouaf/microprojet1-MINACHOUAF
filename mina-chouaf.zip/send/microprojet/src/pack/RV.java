package pack;

public class RV {
private String id;
private String jour;
private String idclient;
private String idcrenerau;

	public RV(String id,String jour,String idcient,String idcrenerau) {
		this.id=id;
		this.jour=jour;
		this.idclient=idclient;
		this.idcrenerau=idcrenerau;
		
	}
	public RV() {
		
	}

	public String getid()
	{
		return this.id;
	}
	public String getjour()
	{
		return this.jour;
	}
	public String getidclient()
	{
		return this.idclient;
	}
	public String getidcrenerau()
	{
		return this.idcrenerau;
	}
	
}
