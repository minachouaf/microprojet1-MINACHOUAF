package pack;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;

import DAO.Clientimp;

public class Clientmain extends JFrame {
	
	private JTextField id;
	private JTextField version;
	private JTextField titre;
	private JTextField nom;
	private JTextField prenom;


	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Medecinemain frame = new Medecinemain();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Clientmain(){
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 977, 683);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(153, 0, 0));
		panel.setBounds(0, 0, 972, 70);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent arg0) {
				System.exit(0);
			}
		});
		
		lblNewLabel.setBounds(932, 11, 30, 30);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_9 = new JLabel("Gestion des Clients");
		lblNewLabel_9.setForeground(Color.WHITE);
		lblNewLabel_9.setFont(new Font("Arial Unicode MS", Font.BOLD, 19));
		lblNewLabel_9.setBounds(338, 19, 245, 22);
		panel.add(lblNewLabel_9);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 0, 0));
		panel_1.setBounds(0, 51, 225, 593);
		contentPane.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setBackground(Color.BLACK);
	
		lblNewLabel_2.setBounds(10, 525, 33, 28);
		panel_1.add(lblNewLabel_2);
		
		JLabel lblNehomewLabel_1 = new JLabel("");
		lblNehomewLabel_1.setBounds(10, 117, 46, 35);
		panel_1.add(lblNehomewLabel_1);
		lblNehomewLabel_1.setBackground(Color.BLACK);
		
		JLabel lblNewLabel_1 = new JLabel("Id:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_1.setBounds(293, 92, 93, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("NOM :");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_3.setBounds(293, 137, 150, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("titre:");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_4.setBounds(293, 188, 93, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("VERSION:");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_5.setBounds(293, 218, 152, 40);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_6 = new JLabel("prenom:");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel_6.setBounds(293, 269, 83, 14);
		contentPane.add(lblNewLabel_6);
		
		id = new JTextField();
		id.setBounds(471, 81, 207, 29);
		contentPane.add(id);
		id.setColumns(10);
		
		nom = new JTextField();
		nom.setBounds(471, 126, 207, 29);
		contentPane.add(nom);
		nom.setColumns(10);
		
		prenom = new JTextField();
		prenom.setBounds(471, 166, 207, 30);
		contentPane.add(prenom);
		prenom.setColumns(10);
		
		version = new JTextField();
		version.setBounds(471, 207, 207, 29);
		contentPane.add(version);
		version.setColumns(10);
		
		titre = new JTextField();
		titre.setBounds(471, 258, 207, 29);
		contentPane.add(titre);
		titre.setColumns(10);
			JButton btnNewButton_3 = new JButton("Supprimer");
			btnNewButton_3.setFont(new Font("Tahoma", Font.BOLD, 12));
			btnNewButton_3.setForeground(Color.WHITE);
			btnNewButton_3.setBackground(Color.BLACK);
			btnNewButton_3.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					try {

						Clientimp p=new Clientimp();
						p.deleteclient(id.getText().toString());
						id.setText("");
						version.setText("");
						titre.setText("");
						nom.setText("");
						prenom.setText("");
				
					

					}catch(Exception ee) {
						ee.printStackTrace();
					}
				}	
				}
			);
		
	
			btnNewButton_3.setBounds(27, 136, 174, 45);
			panel_1.add(btnNewButton_3);
			
				
				JButton btnNewButton_2 = new JButton("Ajouter");
				btnNewButton_2.setBounds(27, 40, 174, 45);
				panel_1.add(btnNewButton_2);
				btnNewButton_2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
	Client a=new Client(id.getText().toString(),version.getText().toString(),titre.getText().toString(),nom.getText().toString(),prenom.getText().toString());
						Clientimp p=new Clientimp();
						p.addclient(a);
						
					}
				});
				
				btnNewButton_2.setFont(new Font("Tahoma", Font.BOLD, 12));
				btnNewButton_2.setForeground(Color.WHITE);
				btnNewButton_2.setBackground(Color.BLACK);
				
				JButton btnNewButton_4 = new JButton("Modifier");
				btnNewButton_4.setFont(new Font("Tahoma", Font.BOLD, 12));
				btnNewButton_4.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						String t1=id.getText();

						String t2=nom.getText();
						String t3=titre.getText();
						String t4=version.getText();
						String t5=prenom.getText();
						Client a=new Client(t1,t2,t3,t4,t5);
						Clientimp R=new Clientimp();
						R.updateclient(a);
						
						
						
						
					}
				});
				JButton btnNewButton_1 = new JButton("Afficher");
				btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
				btnNewButton_1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
					Clientimp R=new Clientimp();
					
						//table.setModel(DbUtils.resultSetToTableModel(R.getmedecines()));
							
								
						}
					
					
				});
				
				
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(229, 341, 732, 303);
				contentPane.add(scrollPane);
				
				table = new JTable();
				table.addMouseListener(new MouseAdapter() {
					@Override
					public void mouseClicked(MouseEvent arg0) {
					
						
					}
				});
				table.setModel(new DefaultTableModel(
					new Object[][] {
						{"1", "554", "f", "mina", "chouaf"},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
						{null, null, null, null, null},
					},
					new String[] {
						"Id", "version", "titre", "nom", "prenom"
					}
				));
				scrollPane.setViewportView(table);
				
				JLabel lblNewLabel_8 = new JLabel("");
				lblNewLabel_8.setIcon(new ImageIcon("C:\\Users\\Amina\\Desktop\\cooperatif p\\c.jpg"));
				lblNewLabel_8.setBounds(272, 51, 734, 294);
				contentPane.add(lblNewLabel_8);
				btnNewButton_1.setBackground(Color.BLACK);
				btnNewButton_1.setForeground(Color.WHITE);
				btnNewButton_1.setBounds(27, 295, 174, 45);
				panel_1.add(btnNewButton_1);

				btnNewButton_4.setBackground(Color.BLACK);
				btnNewButton_4.setForeground(Color.WHITE);
				btnNewButton_4.setBounds(27, 220, 174, 45);
				panel_1.add(btnNewButton_4);
		
		
				JButton btnNewButton = new JButton("Rechercher");
				btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
				btnNewButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						try {
							Clientimp R=new Clientimp();
							
							//table.setModel(DbUtils.resultSetToTableModel(R.getmedecine(id.getText())));
								
									
							

						}catch(Exception e4) {
						
							System.out.println(e4);

					}
					}});
				btnNewButton.setBackground(Color.BLACK);
				btnNewButton.setForeground(Color.WHITE);
				btnNewButton.setBounds(27, 375, 174, 45);
				panel_1.add(btnNewButton);
	}
	private JTable table;
}
