package pack;

public class Crenereux {
private String id;
private String version;
private String hdebut;
private String mdebut;
private String hfin;
private String mfin;
private String idmedecin;

	public Crenereux(String id,String version,String hdebut,String mdebut,String hfin,String mfin,String idmedecin) {
		this.id=id;
		this.version=version;
		this.hdebut=hdebut;
		this.mdebut=mdebut;
		this.hfin=hfin;
		this.mfin=mfin;
		this.idmedecin=idmedecin;
	}
	public Crenereux() {
		
	}

	public String getid()
	{
		return this.id;
	}
	public String getversion()
	{
		return this.version;
	}
	public String gethdebut()
	{
		return this.hdebut;
	}
	public String getmdebut()
	{
		return this.mdebut;
	}
	public String gethfin()
	{
		return this.hfin;
	}
	public String getmfin()
	{
		return this.mfin;
	}
	public String getidmedecin()
	{
		return this.idmedecin;
	}
}
