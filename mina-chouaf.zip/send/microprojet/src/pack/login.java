package pack;

import java.awt.BorderLayout;
import javax.swing.UIManager;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JTextField;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.UIManager;
import java.awt.Window.Type;
import java.sql.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.SwingConstants;
import java.awt.Component;
public class login extends JFrame {

	private JPanel contentPane;
	private JTextField NometPr�nom;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JPasswordField Motdepasse;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		 try {
	            //here you can put the selected theme class name in JTattoo
	            UIManager.setLookAndFeel("com.jtattoo.plaf.aluminium.AluminiumLookAndFeel");
	        } catch (Exception ex) {
	        	System.out.print(ex);
	        }
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					login frame = new login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public login() {
		setType(Type.UTILITY);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 516, 484);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel_1 = new JLabel("Username");
		lblNewLabel_1.setIcon(new ImageIcon("C:\\Users\\Amina\\Desktop\\cooperatif p\\new np.jpeg"));
		lblNewLabel_1.setBounds(63, 135, 67, 41);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_3 = new JLabel("password");
		lblNewLabel_3.setIcon(new ImageIcon("C:\\Users\\Amina\\Desktop\\cooperatif p\\new 9.jpeg"));
		lblNewLabel_3.setBounds(63, 208, 67, 37);
		contentPane.add(lblNewLabel_3);
		
		lblNewLabel_2 = new JLabel("ADMIN LOGIN");
		lblNewLabel_2.setFont(new Font("Arial Narrow", Font.PLAIN, 22));
		lblNewLabel_2.setForeground(Color.DARK_GRAY);
		lblNewLabel_2.setBounds(188, 89, 149, 28);
		contentPane.add(lblNewLabel_2);
		
		NometPr�nom = new JTextField();
		NometPr�nom.setAlignmentX(Component.RIGHT_ALIGNMENT);
		NometPr�nom.setFont(new Font("Arial Black", Font.BOLD, 13));
		NometPr�nom.setBounds(156, 148, 229, 28);
		contentPane.add(NometPr�nom);
		NometPr�nom.setColumns(10);
		
		JButton btnNewButton = new JButton("LOG IN");
	
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con=DriverManager.getConnection("jdbc:mysql://localhost/microprojet","root","");
					Statement stmt=con.createStatement();
					String sql="Select * from Admin where NometPr�nom='"+NometPr�nom.getText()+"' and Motdepasse='"+Motdepasse.getText().toString()+"'"; 
				ResultSet rs=stmt.executeQuery(sql);
				
				if(rs.next()) {
					
					JOptionPane.showMessageDialog(null,"login succefully...");
				admininterface ad=new admininterface();
				ad.setVisible(true);
				}else
				{
					JOptionPane.showMessageDialog(null,"connection failed");
				}
				con.close();
				}catch(Exception e){System.out.print(e);}
				
				
			}
		});
		btnNewButton.setFocusPainted(false);
		btnNewButton.setFocusTraversalKeysEnabled(false);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setIcon(null);
		btnNewButton.setBackground(new Color(102, 0, 0));
		btnNewButton.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 14));
		btnNewButton.setBounds(144, 302, 241, 37);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel_4 = new JLabel("");
		lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\Amina\\Desktop\\cooperatif p\\agayo.jpeg"));
		lblNewLabel_4.setBounds(211, 11, 67, 67);
		contentPane.add(lblNewLabel_4);
		
		Motdepasse = new JPasswordField();
		Motdepasse.setBounds(156, 212, 229, 28);
		contentPane.add(Motdepasse);
		
		JButton btnNewButton_1 = new JButton("Quitter");
		
		
			
	
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setFont(new Font("Arial Rounded MT Bold", Font.BOLD, 14));
		btnNewButton_1.setBackground(new Color(102, 0, 0));
		btnNewButton_1.setBounds(144, 357, 241, 37);
		contentPane.add(btnNewButton_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.TRAILING);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\admin\\eclipse-workspace\\microprojet\\src\\arton23179.jpg"));
		lblNewLabel.setBounds(0, 0, 500, 436);
		contentPane.add(lblNewLabel);
		
		
		setBorder(BorderFactory.createEmptyBorder(0,0,0,0));
		
	}

	private void setBorder(Border createEmptyBorder) {
		// TODO Auto-generated method stub
		
	}
}
