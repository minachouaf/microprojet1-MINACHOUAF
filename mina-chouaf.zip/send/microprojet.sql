-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Dim 09 Février 2020 à 20:34
-- Version du serveur :  10.1.10-MariaDB
-- Version de PHP :  5.5.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `microprojet`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

CREATE TABLE `admin` (
  `NometPrénom` varchar(40) NOT NULL,
  `Motdepasse` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `admin`
--

INSERT INTO `admin` (`NometPrénom`, `Motdepasse`) VALUES
('mina', '123');

-- --------------------------------------------------------

--
-- Structure de la table `clients`
--

CREATE TABLE `clients` (
  `ID` bigint(30) NOT NULL,
  `VERSION` int(11) NOT NULL,
  `TITRE` varchar(5) NOT NULL,
  `NOM` varchar(30) NOT NULL,
  `PRENOM` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `clients`
--

INSERT INTO `clients` (`ID`, `VERSION`, `TITRE`, `NOM`, `PRENOM`) VALUES
(1, 12, 'jjk', 'ff', 'ggg');

-- --------------------------------------------------------

--
-- Structure de la table `creneraux`
--

CREATE TABLE `creneraux` (
  `ID` bigint(20) NOT NULL,
  `VERSION` int(11) NOT NULL,
  `HDEBUT` int(11) NOT NULL,
  `MDEBUT` int(11) NOT NULL,
  `HFIN` int(11) NOT NULL,
  `MFIN` int(11) NOT NULL,
  `ID_MEDECIN` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `creneraux`
--

INSERT INTO `creneraux` (`ID`, `VERSION`, `HDEBUT`, `MDEBUT`, `HFIN`, `MFIN`, `ID_MEDECIN`) VALUES
(1, 4, 2, 3, 5, 7, 6),
(2, 12, 12, 12, 12, 12, 12);

-- --------------------------------------------------------

--
-- Structure de la table `medecins`
--

CREATE TABLE `medecins` (
  `ID` bigint(30) NOT NULL,
  `version` int(30) NOT NULL,
  `TITRE` varchar(5) NOT NULL,
  `NOM` varchar(30) NOT NULL,
  `PRENOM` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `medecins`
--

INSERT INTO `medecins` (`ID`, `version`, `TITRE`, `NOM`, `PRENOM`) VALUES
(1, 12, 'DDD', 'ZZ', 'ZZ'),
(22, 55, '66', '122222', '44');

-- --------------------------------------------------------

--
-- Structure de la table `rv`
--

CREATE TABLE `rv` (
  `ID` bigint(20) NOT NULL,
  `JOUR` varchar(40) NOT NULL,
  `ID_CLIENT` int(20) NOT NULL,
  `ID_CRENEAU` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `rv`
--

INSERT INTO `rv` (`ID`, `JOUR`, `ID_CLIENT`, `ID_CRENEAU`) VALUES
(1, 'FF', 33, 666);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`Motdepasse`),
  ADD UNIQUE KEY `Motdepasse` (`Motdepasse`);

--
-- Index pour la table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `creneraux`
--
ALTER TABLE `creneraux`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `medecins`
--
ALTER TABLE `medecins`
  ADD PRIMARY KEY (`ID`);

--
-- Index pour la table `rv`
--
ALTER TABLE `rv`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `creneraux`
--
ALTER TABLE `creneraux`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT pour la table `rv`
--
ALTER TABLE `rv`
  MODIFY `ID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
